export default function FindPlayer() {
  return (
    <div style={{ marginTop: '20px' }}>
      <h2 style={{ fontSize: '24px' }}>Find Players</h2>
      <p>This is where players will be listed. Coming soon!</p>
    </div>
  );
}

